# global_variables.py
selected_image = ""