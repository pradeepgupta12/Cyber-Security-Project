from gui2 import show_register_interface
from gui import show_login_interface
from gui3 import show_home_interface
from gui4 import show_encoding_interface
from gui5 import show_decoding_interface

if __name__ == "__main__":
    # Call the functions to show the interfaces
    show_register_interface()
    show_login_interface()
    show_home_interface()
    show_encoding_interface()
    show_decoding_interface()
